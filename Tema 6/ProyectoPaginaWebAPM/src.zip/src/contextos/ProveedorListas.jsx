import React, { useState, createContext, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabase/supabase.js";
import useSesion from "../hooks/useSesion.jsx";

const contextoListas = createContext();

const ProveedorListas = ({children}) => {

  const [lista, setLista] = useState([]);
  const [cantidad, setCantidad] = useState(1);
  const [mostrarPopUpCesta, setMostrarPopUp] = useState(false);
  const [errorListas, setErrorListas] = useState("");
  const [productosLista, setProductosLista] = useState([]);
  const [idListaActual, setIdListaActual] = useState("");
  const [funciona, setFunciona] = useState(false);
  const [newLista, setNewLista] = useState(null);

  const { usuario } = useSesion();

  const cargarListas = async () => {

    try {
      const {data, error} = await supabase.from("listaCompra").select("*");
      console.log("hola" + data);
      if (error) {
        setErrorListas(error.message);
      } else {
        setLista(data);
      }
    } catch (fallo) {
      setErrorListas(fallo.message);
    }

  };




  const datosAExportar = {
    cargarListas,
  };

  return (
    <>
    <contextoListas.Provider value={datosAExportar}>
        {children}
    </contextoListas.Provider>
    </>
  );
};

export default ProveedorListas;
export { contextoListas };