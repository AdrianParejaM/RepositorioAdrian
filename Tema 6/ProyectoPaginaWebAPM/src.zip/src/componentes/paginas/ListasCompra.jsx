import React, { useState, useContext, useEffect } from "react";
import { contextoListas } from "../../contextos/ProveedorListas.jsx";

const ListasCompra = () => {

    //Importamos lo necesario.
    const { cargarListas } = useContext(contextoListas);

    useEffect(() => {
      cargarListas();
    }, []);

  return (
    <>
    <h1>Listas de la compra</h1>

    </>
  );
};

export default ListasCompra;