const generarUuidAleatorio = () => {
    return crypto.randomUUID();
};

export { generarUuidAleatorio };